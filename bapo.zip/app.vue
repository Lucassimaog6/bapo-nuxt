<template>
  <NuxtPage/>
</template>
